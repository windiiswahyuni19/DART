package com.example.panduan

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
