class User {
  User({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    this.phone,
    this.address,
    this.createdAt,
    this.lastLogin,
  });

  final String id;
  final String name;
  final String email;
  final String role;
  final String? phone;
  final String? address;
  final DateTime? createdAt;
  final DateTime? lastLogin;

  factory User.fromFirestore(Map<String, dynamic> map, String id) {
    return User(
      id: id,
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      role: map['role'] ?? 'Petani',
      phone: map['phone'],
      address: map['address'],
      createdAt: map['createdAt']?.toDate(),
      lastLogin: map['lastLogin']?.toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'role': role,
      'phone': phone,
      'address': address,
      'createdAt': createdAt ?? DateTime.now(),
      'lastLogin': lastLogin,
    };
  }
}