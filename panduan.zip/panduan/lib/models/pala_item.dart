class PalaItem {
  PalaItem({
    required this.nama,
    required this.jenisTanah,
    required this.ukuranLahan,
    required this.tahunTanam,
    required this.lamaTanam,
    required this.saran,
    required this.isSehat,
    this.imageBase64,
    this.userId,
    this.createdAt,
    this.updatedAt,
  });

  final String nama;
  final String jenisTanah;
  final String ukuranLahan;
  final int tahunTanam;
  final String lamaTanam;
  final String saran;
  final bool isSehat;
  final String? imageBase64;
  final String? userId;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Map<String, dynamic> toMap() {
    return {
      'nama': nama,
      'jenisTanah': jenisTanah,
      'ukuranLahan': ukuranLahan,
      'tahunTanam': tahunTanam,
      'lamaTanam': lamaTanam,
      'saran': saran,
      'isSehat': isSehat,
      'imageBase64': imageBase64,
      'userId': userId,
      'createdAt': createdAt ?? DateTime.now(),
      'updatedAt': DateTime.now(),
    };
  }

  factory PalaItem.fromMap(Map<String, dynamic> map) {
    return PalaItem(
      nama: map['nama'] ?? '',
      jenisTanah: map['jenisTanah'] ?? '',
      ukuranLahan: map['ukuranLahan'] ?? '',
      tahunTanam: map['tahunTanam'] ?? DateTime.now().year,
      lamaTanam: map['lamaTanam'] ?? '',
      saran: map['saran'] ?? '',
      isSehat: map['isSehat'] ?? true,
      imageBase64: map['imageBase64'],
      userId: map['userId'],
      createdAt: map['createdAt']?.toDate(),
      updatedAt: map['updatedAt']?.toDate(),
    );
  }

  PalaItem copyWith({
    String? nama,
    String? jenisTanah,
    String? ukuranLahan,
    int? tahunTanam,
    String? lamaTanam,
    String? saran,
    bool? isSehat,
    String? imageBase64,
    String? userId,
  }) {
    return PalaItem(
      nama: nama ?? this.nama,
      jenisTanah: jenisTanah ?? this.jenisTanah,
      ukuranLahan: ukuranLahan ?? this.ukuranLahan,
      tahunTanam: tahunTanam ?? this.tahunTanam,
      lamaTanam: lamaTanam ?? this.lamaTanam,
      saran: saran ?? this.saran,
      isSehat: isSehat ?? this.isSehat,
      imageBase64: imageBase64 ?? this.imageBase64,
      userId: userId ?? this.userId,
      createdAt: createdAt,
      updatedAt: updatedAt,
    );
  }
}