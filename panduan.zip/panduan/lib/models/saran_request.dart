class SaranRequest {
  SaranRequest({
    required this.id,
    required this.userId,
    required this.userName,
    required this.userEmail,
    required this.plantName,
    required this.soilType,
    required this.plantYear,
    required this.symptoms,
    required this.plantImage,
    this.advice,
    this.adminId,
    this.adminName,
    this.adminReply,
    this.status = 'pending', // pending, replied, completed
    this.createdAt,
    this.repliedAt,
  });

  final String id;
  final String userId;
  final String userName;
  final String userEmail;
  final String plantName;
  final String soilType;
  final String plantYear;
  final String symptoms;
  final String plantImage;
  final String? advice;
  final String? adminId;
  final String? adminName;
  final String? adminReply;
  final String status;
  final DateTime? createdAt;
  final DateTime? repliedAt;

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'userName': userName,
      'userEmail': userEmail,
      'plantName': plantName,
      'soilType': soilType,
      'plantYear': plantYear,
      'symptoms': symptoms,
      'plantImage': plantImage,
      'advice': advice,
      'adminId': adminId,
      'adminName': adminName,
      'adminReply': adminReply,
      'status': status,
      'createdAt': createdAt ?? DateTime.now(),
      'repliedAt': repliedAt,
    };
  }

  factory SaranRequest.fromMap(Map<String, dynamic> map, String id) {
    return SaranRequest(
      id: id,
      userId: map['userId'] ?? '',
      userName: map['userName'] ?? '',
      userEmail: map['userEmail'] ?? '',
      plantName: map['plantName'] ?? '',
      soilType: map['soilType'] ?? '',
      plantYear: map['plantYear'] ?? '',
      symptoms: map['symptoms'] ?? '',
      plantImage: map['plantImage'] ?? '',
      advice: map['advice'],
      adminId: map['adminId'],
      adminName: map['adminName'],
      adminReply: map['adminReply'],
      status: map['status'] ?? 'pending',
      createdAt: map['createdAt']?.toDate(),
      repliedAt: map['repliedAt']?.toDate(),
    );
  }

  SaranRequest copyWith({
    String? advice,
    String? adminId,
    String? adminName,
    String? adminReply,
    String? status,
    DateTime? repliedAt,
  }) {
    return SaranRequest(
      id: id,
      userId: userId,
      userName: userName,
      userEmail: userEmail,
      plantName: plantName,
      soilType: soilType,
      plantYear: plantYear,
      symptoms: symptoms,
      plantImage: plantImage,
      advice: advice ?? this.advice,
      adminId: adminId ?? this.adminId,
      adminName: adminName ?? this.adminName,
      adminReply: adminReply ?? this.adminReply,
      status: status ?? this.status,
      createdAt: createdAt,
      repliedAt: repliedAt ?? this.repliedAt,
    );
  }
}