import 'package:flutter/material.dart';

const Color kPalaGreen = Color(0xFF2E7D32);
const String kAppName = 'PalaCare';
const String kAppDescription = 'Solusi perawatan tanaman pala';

class AppRoutes {
  static const String splash = '/';
  static const String login = '/login';
  static const String register = '/register';
  static const String forgotPassword = '/forgot-password';
  static const String home = '/home';
  static const String detail = '/detail';
  static const String addEditPala = '/add-edit-pala';
  static const String saran = '/saran';
  static const String profile = '/profile';
}