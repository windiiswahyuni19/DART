class AdviceGenerator {
  static String generateAdvice({
    required String plantName,
    required String soilType,
    required String plantYear,
    required String symptoms,
  }) {
    final s = symptoms.toLowerCase();
    final buffer = StringBuffer();
    
    buffer.writeln('Ringkasan singkat:');
    if (plantName.isNotEmpty) buffer.writeln('- Tanaman: $plantName');
    if (soilType.isNotEmpty) buffer.writeln('- Jenis tanah: $soilType');
    if (plantYear.isNotEmpty) buffer.writeln('- Tahun tanam: $plantYear');
    buffer.writeln('\nAnalisis & saran:');

    if (s.contains('kuning') || s.contains('daun kuning')) {
      buffer.writeln('- Daun kuning: kemungkinan kekurangan nitrogen. Berikan pupuk N atau kompos, evaluasi kelembapan.');
    }
    if (s.contains('layu') || s.contains('mati')) {
      buffer.writeln('- Layu: cek akar dan drainase, kurangi penyiraman bila tergenang, gunakan biopestisida bila perlu.');
    }
    if (s.contains('bercak') || s.contains('jamur') || s.contains('spot')) {
      buffer.writeln('- Bercak/jamur: pangkas daun terinfeksi, gunakan fungisida atau larutan tembaga sesuai dosis.');
    }
    if (s.trim().isEmpty) {
      buffer.writeln('- Tidak ada gejala spesifik: lakukan pemupukan seimbang (NPK), pangkas, dan observasi 2 minggu.');
    }
    
    buffer.writeln('\nLangkah praktis: 1) Ambil foto & catat, 2) monitor 14 hari, 3) jika memburuk, konsultasikan ke penyuluh lokal.');
    return buffer.toString();
  }
}