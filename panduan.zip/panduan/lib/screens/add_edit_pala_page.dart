import 'package:flutter/material.dart';
import '../../models/pala_item.dart';
import '../../services/firestore_services.dart';
import '../../services/image_service.dart';
import '../../services/shared_prefs_services.dart';

class AddEditPalaPage extends StatefulWidget {
  final String? palaId;
  final PalaItem? initialData;

  const AddEditPalaPage({
    super.key,
    this.palaId,
    this.initialData,
  });

  @override
  State<AddEditPalaPage> createState() => _AddEditPalaPageState();
}

class _AddEditPalaPageState extends State<AddEditPalaPage> {
  final _formKey = GlobalKey<FormState>();
  final FirestoreService _firestoreService = FirestoreService();
  final ImageService _imageService = ImageService();
  final SharedPrefsService _prefsService = SharedPrefsService();

  late final TextEditingController _namaC;
  late final TextEditingController _tanahC;
  late final TextEditingController _ukuranC;
  late final TextEditingController _tahunC;
  late final TextEditingController _lamaC;
  late final TextEditingController _saranC;
  late bool _isSehat;

  String? _imageBase64;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    final d = widget.initialData;

    _namaC = TextEditingController(text: d?.nama ?? '');
    _tanahC = TextEditingController(text: d?.jenisTanah ?? '');
    _ukuranC = TextEditingController(text: d?.ukuranLahan ?? '');
    _tahunC = TextEditingController(
        text: d?.tahunTanam != null ? d!.tahunTanam.toString() : '${DateTime.now().year}');
    _lamaC = TextEditingController(text: d?.lamaTanam ?? '');
    _saranC = TextEditingController(text: d?.saran ?? '');
    _isSehat = d?.isSehat ?? true;
    _imageBase64 = d?.imageBase64;
  }

  @override
  void dispose() {
    _namaC.dispose();
    _tanahC.dispose();
    _ukuranC.dispose();
    _tahunC.dispose();
    _lamaC.dispose();
    _saranC.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    try {
      final imageBase64 = await _imageService.pickAndConvertImage();
      if (imageBase64 != null) {
        setState(() => _imageBase64 = imageBase64);
      }
    } catch (e) {
      _showSnackBar('Gagal memilih gambar.');
    }
  }

  Future<void> _savePala() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final userData = await _prefsService.getUserData();
      
      final pala = PalaItem(
        nama: _namaC.text,
        jenisTanah: _tanahC.text,
        ukuranLahan: _ukuranC.text,
        tahunTanam: int.tryParse(_tahunC.text) ?? DateTime.now().year,
        lamaTanam: _lamaC.text,
        saran: _saranC.text,
        isSehat: _isSehat,
        imageBase64: _imageBase64,
        userId: userData['userId'],
      );

      await _firestoreService.savePala(pala, palaId: widget.palaId);

      _showSnackBar(widget.palaId != null ? 'Data berhasil diupdate' : 'Data berhasil ditambah');
      if (mounted) {
        Navigator.pop(context);
      }
    } catch (e) {
      _showSnackBar('Gagal menyimpan: $e');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Widget _buildImageWidget() {
    final imageBytes = _imageService.decodeBase64Image(_imageBase64);

    if (imageBytes != null) {
      return Image.memory(imageBytes, fit: BoxFit.cover);
    }
    return Image.asset(
      "assets/images/pala.jpeg",
      fit: BoxFit.cover,
    );
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.palaId != null;

    return Scaffold(
      appBar: AppBar(title: Text(isEdit ? 'Edit Pala' : 'Tambah Pala')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: ListView(
                  children: [
                    Center(
                      child: GestureDetector(
                        onTap: _pickImage,
                        child: Container(
                          width: 170,
                          height: 170,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            color: Colors.grey[200],
                            border: Border.all(color: Colors.grey[300]!),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(16),
                            child: _buildImageWidget(),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Center(
                      child: TextButton.icon(
                        onPressed: _pickImage,
                        icon: const Icon(Icons.camera_alt),
                        label: const Text('Pilih Gambar'),
                      ),
                    ),

                    const SizedBox(height: 20),

                    TextFormField(
                      controller: _namaC,
                      decoration: const InputDecoration(
                        labelText: 'Nama Pala',
                        border: OutlineInputBorder(),
                      ),
                      validator: (v) => v == null || v.isEmpty ? 'Harus diisi' : null,
                    ),
                    const SizedBox(height: 16),

                    TextFormField(
                      controller: _tanahC,
                      decoration: const InputDecoration(
                        labelText: 'Jenis Tanah',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 16),

                    TextFormField(
                      controller: _ukuranC,
                      decoration: const InputDecoration(
                        labelText: 'Ukuran Lahan',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 16),

                    TextFormField(
                      controller: _tahunC,
                      decoration: const InputDecoration(
                        labelText: 'Tahun Tanam',
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    const SizedBox(height: 16),

                    TextFormField(
                      controller: _lamaC,
                      decoration: const InputDecoration(
                        labelText: 'Lama Tanam',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 16),

                    TextFormField(
                      controller: _saranC,
                      decoration: const InputDecoration(
                        labelText: 'Saran Perawatan',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 3,
                    ),

                    const SizedBox(height: 20),

                    Card(
                      child: SwitchListTile(
                        value: _isSehat,
                        onChanged: (v) => setState(() => _isSehat = v),
                        title: const Text('Status Tanaman Sehat'),
                        subtitle: const Text('Nonaktifkan jika tanaman butuh perawatan'),
                      ),
                    ),

                    const SizedBox(height: 24),

                    ElevatedButton(
                      onPressed: _isLoading ? null : _savePala,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      child: _isLoading
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : Text(
                              isEdit ? 'Simpan Perubahan' : 'Tambah Pala',
                              style: const TextStyle(fontSize: 16),
                            ),
                    )
                  ],
                ),
              ),
            ),
    );
  }
}