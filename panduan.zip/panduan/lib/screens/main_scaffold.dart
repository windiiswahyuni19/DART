import 'package:flutter/material.dart';
import '../../utils/constants.dart';
import 'home_page.dart';
import 'saran_page.dart';
import 'profile_page.dart';
import '../widgets/app_drawer.dart';

class MainScaffold extends StatefulWidget {
  final String role;
  final String? userName;
  const MainScaffold({super.key, required this.role, this.userName});

  @override
  State<MainScaffold> createState() => _MainScaffoldState();
}

class _MainScaffoldState extends State<MainScaffold> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: AppDrawer(
        userName: widget.userName,
        userRole: widget.role, // Kirim role ke AppDrawer
      ),
      appBar: AppBar(
        title: const Text('PalaCare'),
        elevation: 2,
      ),
      body: _buildPages()[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        selectedItemColor: kPalaGreen,
        onTap: (idx) => setState(() => _selectedIndex = idx),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.lightbulb_outline), label: 'Saran'),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Profil'),
        ],
      ),
    );
  }

  List<Widget> _buildPages() => [
        HomePage(role: widget.role, userName: widget.userName),
        SaranPage(role: widget.role),
        ProfilePage(userName: widget.userName, userRole: widget.role),
      ];
}