import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../services/auth_services.dart';
import '../../services/shared_prefs_services.dart';
import '../../utils/constants.dart';
import 'main_scaffold.dart';
import 'register_page.dart';
import 'forgot_password_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String? _role;
  final _nameCtl = TextEditingController();
  final _emailCtl = TextEditingController();
  final _passCtl = TextEditingController();
  final AuthService _authService = AuthService();
  final SharedPrefsService _prefsService = SharedPrefsService();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _prefsService.setDefaultPenyuluhAccount();
  }

  @override
  void dispose() {
    _nameCtl.dispose();
    _emailCtl.dispose();
    _passCtl.dispose();
    super.dispose();
  }

  Future<void> _tryLogin() async {
    if (_emailCtl.text.isEmpty || _passCtl.text.isEmpty) {
      _showSnackBar('Isi email dan password untuk login.');
      return;
    }

    setState(() => _isLoading = true);

    try {
      // Login Penyuluh
      if (_role == "Penyuluh") {
        final penyuluhAccount = await _prefsService.getPenyuluhAccount();
        if (_emailCtl.text == penyuluhAccount['email'] && 
            _passCtl.text == penyuluhAccount['password']) {
          
          await _prefsService.setIsLoggedIn(true);
          await _prefsService.saveUserData(
            role: "Penyuluh",
            name: penyuluhAccount['name']!,
            email: penyuluhAccount['email']!,
            userId: 'penyuluh',
          );

          if (mounted) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (_) => MainScaffold(
                  role: "Penyuluh",
                  userName: penyuluhAccount['name'],
                ),
              ),
            );
          }
          return;
        } else {
          _showSnackBar("Email atau password penyuluh salah.");
          return;
        }
      }

      // Login Petani
      final user = await _authService.loginPetani(
        _emailCtl.text.trim(),
        _passCtl.text,
      );

      if (user != null) {
        await _prefsService.setIsLoggedIn(true);
        await _prefsService.saveUserData(
          role: "Petani",
          name: user.name,
          email: user.email,
          userId: user.id,
        );

        final finalName = _nameCtl.text.trim().isEmpty ? 
            user.name : _nameCtl.text.trim();

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => MainScaffold(
                role: "Petani",
                userName: finalName,
              ),
            ),
          );
        }
      }
    } catch (e) {
      _showSnackBar(e.toString());
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login — PalaCare')),
      body: _isLoading 
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Center(
          child: Card(
            elevation: 8,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(18.0),
              child: SizedBox(
                width: 420,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'Masuk ke PalaCare',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),

                    TextField(
                      controller: _nameCtl,
                      decoration: InputDecoration(
                        labelText: 'Nama (opsional)',
                        prefixIcon: const Icon(Icons.person),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                    const SizedBox(height: 12),

                    TextField(
                      controller: _emailCtl,
                      decoration: InputDecoration(
                        labelText: 'Email',
                        prefixIcon: const Icon(Icons.email),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      keyboardType: TextInputType.emailAddress,
                    ),
                    const SizedBox(height: 12),

                    TextField(
                      controller: _passCtl,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        prefixIcon: const Icon(Icons.lock),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      obscureText: true,
                    ),
                    const SizedBox(height: 12),

                    DropdownButtonFormField<String>(
                      value: _role,
                      hint: const Text('Pilih jenis pengguna'),
                      items: const [
                        DropdownMenuItem(value: 'Penyuluh', child: Text('Penyuluh')),
                        DropdownMenuItem(value: 'Petani', child: Text('Petani')),
                      ],
                      onChanged: (v) => setState(() => _role = v),
                      decoration: InputDecoration(
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                    const SizedBox(height: 16),

                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _tryLogin,
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: _isLoading 
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Text('Masuk', style: TextStyle(fontSize: 16)),
                      ),
                    ),

                    const SizedBox(height: 10),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const ForgotPasswordPage()),
                            );
                          },
                          child: const Text('Lupa Password?'),
                        ),

                        if (_role != "Penyuluh")
                          TextButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (_) => const RegisterPage()),
                              );
                            },
                            child: const Text('Daftar akun'),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}