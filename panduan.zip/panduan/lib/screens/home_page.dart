import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/pala_item.dart';
import '../../services/firestore_services.dart';
import '../../utils/constants.dart';
import '../widgets/image_widget.dart';
import 'detail_page.dart';
import 'add_edit_pala_page.dart';

class HomePage extends StatefulWidget {
final String role;
final String? userName;

const HomePage({
super.key,
required this.role,
this.userName,
});

@override
State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
final FirestoreService _firestoreService = FirestoreService();
final FirebaseFirestore _firestore = FirebaseFirestore.instance;

@override
Widget build(BuildContext context) {
final isPenyuluh = widget.role == "Penyuluh";

return Scaffold(
  appBar: AppBar(
    title: Text("Selamat datang, ${widget.userName ?? ''}"),
  ),
  floatingActionButton: isPenyuluh
      ? FloatingActionButton(
          onPressed: () async {
            await Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AddEditPalaPage()),
            );
            setState(() {});
          },
          child: const Icon(Icons.add),
        )
      : null,
  body: StreamBuilder<QuerySnapshot>(
    stream: _firestoreService.getPalasStream(),
    builder: (context, snapshot) {
      if (snapshot.hasError) {
        return Center(child: Text('Error: ${snapshot.error}'));
      }

      if (snapshot.connectionState == ConnectionState.waiting) {
        return const Center(child: CircularProgressIndicator());
      }

      final palas = snapshot.data!.docs;

      if (palas.isEmpty) {
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.local_florist, size: 64, color: Colors.grey[400]),
              const SizedBox(height: 16),
              const Text(
                'Belum ada data tanaman pala',
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              if (isPenyuluh) ...[
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const AddEditPalaPage()),
                    );
                  },
                  child: const Text('Tambah Pala Pertama'),
                ),
              ],
            ],
          ),
        );
      }

      return ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: palas.length,
        itemBuilder: (context, index) {
          final doc = palas[index];
          final data = doc.data() as Map<String, dynamic>;

          return Card(
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: ImageWidget(imageBase64: data['imageBase64']),
              ),
              title: Text(data['nama'] ?? ''),
              subtitle:
                  Text("Tahun tanam: ${data['tahunTanam'] ?? ''}"),
              trailing: (data['isSehat'] ?? true)
                  ? const Icon(Icons.health_and_safety, color: Colors.green)
                  : const Icon(Icons.warning, color: Colors.orange),
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => DetailPage(
                      role: widget.role,
                      palaId: doc.id,
                    ),
                  ),
                );
                if (mounted) setState(() {});
              },
            ),
          );
        },
      );
    },
  ),
);

}
}