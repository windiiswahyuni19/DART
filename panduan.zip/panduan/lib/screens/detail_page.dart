import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/pala_item.dart';
import '../../services/firestore_services.dart';
import '../../utils/constants.dart';
import '../widgets/image_widget.dart';
import 'add_edit_pala_page.dart';
import 'petani_saran_page.dart';

class DetailPage extends StatefulWidget {
final String role;
final String palaId;

const DetailPage({
super.key,
required this.role,
required this.palaId,
});

@override
State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
final FirestoreService _firestoreService = FirestoreService();

Future<void> _deletePala() async {
try {
await _firestoreService.deletePala(widget.palaId);
if (mounted) {
Navigator.pop(context);
ScaffoldMessenger.of(context).showSnackBar(
const SnackBar(content: Text('Data pala berhasil dihapus')),
);
}
} catch (e) {
if (mounted) {
ScaffoldMessenger.of(context).showSnackBar(
SnackBar(content: Text('Gagal menghapus: $e')),
);
}
}
}

@override
Widget build(BuildContext context) {
final isPenyuluh = widget.role == 'Penyuluh';

return Scaffold(
  appBar: AppBar(title: const Text("Detail Tanaman")),
  body: StreamBuilder<DocumentSnapshot>(
    stream: FirebaseFirestore.instance
        .collection('pala')
        .doc(widget.palaId)
        .snapshots(),
    builder: (context, snapshot) {
      if (snapshot.hasError) {
        return Center(child: Text("Error: ${snapshot.error}"));
      }

      if (!snapshot.hasData || !snapshot.data!.exists) {
        return const Center(child: CircularProgressIndicator());
      }

      final data = snapshot.data!.data() as Map<String, dynamic>;
      final pala = PalaItem.fromMap(data);

      return SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14)),
              elevation: 6,
              clipBehavior: Clip.antiAlias,
              child: Column(
                children: [
                  ImageWidget(
                    imageBase64: pala.imageBase64,
                    width: double.infinity,
                    height: 220,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          pala.nama,
                          style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 6),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            Chip(label: Text(pala.jenisTanah)),
                            Chip(label: Text(pala.ukuranLahan)),
                            Chip(label: Text('${pala.tahunTanam}')),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            const Text(
                              'Status: ',
                              style:
                                  TextStyle(fontWeight: FontWeight.bold),
                            ),
                            Text(
                              pala.isSehat
                                  ? 'Sehat'
                                  : 'Butuh Perawatan',
                              style: TextStyle(
                                color: pala.isSehat
                                    ? Colors.green
                                    : Colors.red,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'Saran Perawatan',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 6),
                        Text(pala.saran),
                        const SizedBox(height: 14),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            if (isPenyuluh)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  ElevatedButton.icon(
                    icon: const Icon(Icons.edit),
                    label: const Text('Edit'),
                    onPressed: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AddEditPalaPage(
                            palaId: widget.palaId,
                            initialData: pala,
                          ),
                        ),
                      );
                    },
                  ),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.delete),
                    label: const Text('Hapus'),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red.shade700),
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (_) => AlertDialog(
                          title: const Text('Hapus Pala'),
                          content: Text('Hapus ${pala.nama}?'),
                          actions: [
                            TextButton(
                              onPressed: () =>
                                  Navigator.pop(context),
                              child: const Text('Batal'),
                            ),
                            TextButton(
                              child: const Text(
                                'Hapus',
                                style: TextStyle(color: Colors.red),
                              ),
                              onPressed: () {
                                Navigator.pop(context);
                                _deletePala();
                              },
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ],
              ),

            if (!isPenyuluh)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.lightbulb_outline),
                  label:
                      const Text('Minta Saran untuk Tanaman Ini'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => PetaniSaranPage(
                          prefillName: pala.nama,
                          prefillTanah: pala.jenisTanah,
                          prefillTahun: pala.tahunTanam.toString(),
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      );
    },
  ),
);

}
}