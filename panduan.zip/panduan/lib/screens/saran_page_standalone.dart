import 'package:flutter/material.dart';
import 'petani_saran_page.dart';

class SaranPageStandalone extends StatelessWidget {
  const SaranPageStandalone({super.key});
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Minta Saran')),
      body: const PetaniSaranPage(),
    );
  }
}