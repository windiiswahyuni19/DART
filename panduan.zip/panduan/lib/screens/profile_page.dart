import 'package:flutter/material.dart';
import '../../utils/constants.dart';

class ProfilePage extends StatelessWidget {
  final String? userName;
  final String? userRole;
  const ProfilePage({super.key, this.userName, this.userRole});
  
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16), 
        children: [
          const SizedBox(height: 20),
          CircleAvatar(
            radius: 46, 
            backgroundColor: kPalaGreen,
            child: Icon(Icons.person, size: 46, color: Colors.white),
          ),
          const SizedBox(height: 16),
          Text(
            userName ?? 'Pengguna PalaCare', 
            textAlign: TextAlign.center, 
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)
          ),
          const SizedBox(height: 8),
          const Text(
            'user@palacare.local', 
            textAlign: TextAlign.center, 
            style: TextStyle(color: Colors.grey)
          ),
          const SizedBox(height: 32),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12), 
              child: Column(children: [
                ListTile(
                  leading: const Icon(Icons.info_outline), 
                  title: const Text('Tentang'), 
                  subtitle: const Text('Versi 1.0 — Prototype PalaCare')
                ),
                ListTile(
                  leading: const Icon(Icons.help_outline), 
                  title: const Text('Bantuan'), 
                  subtitle: const Text('Panduan & kontak penyuluh')
                ),
              ])
            )
          ),
        ]
      ),
    );
  }
}