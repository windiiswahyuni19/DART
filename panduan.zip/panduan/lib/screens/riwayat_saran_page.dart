import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/firestore_services.dart';
import '../../services/shared_prefs_services.dart';
import '../../models/saran_request.dart';
import '../widgets/image_widget.dart';

class RiwayatSaranPage extends StatefulWidget {
  const RiwayatSaranPage({super.key});

  @override
  State<RiwayatSaranPage> createState() => _RiwayatSaranPageState();
}

class _RiwayatSaranPageState extends State<RiwayatSaranPage> {
  final FirestoreService _firestoreService = FirestoreService();
  final SharedPrefsService _prefsService = SharedPrefsService();
  String? _userId;

  @override
  void initState() {
    super.initState();
    _getUserId();
  }

  Future<void> _getUserId() async {
    final userData = await _prefsService.getUserData();
    setState(() {
      _userId = userData['userId'];
    });
  }

  Widget _buildSaranItem(DocumentSnapshot doc) {
    final request = SaranRequest.fromMap(doc.data() as Map<String, dynamic>, doc.id);
    
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  request.plantName,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                Chip(
                  label: Text(
                    request.status == 'pending' ? 'Menunggu' : 
                    request.status == 'replied' ? 'Sudah Dibalas' : 'Selesai',
                    style: const TextStyle(color: Colors.white, fontSize: 12),
                  ),
                  backgroundColor: request.status == 'pending' ? Colors.orange : 
                                 request.status == 'replied' ? Colors.green : Colors.blue,
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text('Jenis Tanah: ${request.soilType}'),
            Text('Tahun Tanam: ${request.plantYear}'),
            const SizedBox(height: 8),
            const Text('Keluhan Anda:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(request.symptoms),
            
            if (request.plantImage.isNotEmpty) ...[
              const SizedBox(height: 8),
              const Text('Foto Tanaman:', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Container(
                height: 100,
                width: 100,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: ImageWidget(imageBase64: request.plantImage),
              ),
            ],
            
            if (request.adminReply != null) ...[
              const SizedBox(height: 8),
              const Text('Saran dari Penyuluh:', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
              Text(request.adminReply!),
              const SizedBox(height: 4),
              Text(
                'Dibalas oleh: ${request.adminName}',
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              ),
              Text(
                'Pada: ${request.repliedAt?.toString().split(' ')[0] ?? ''}',
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ] else if (request.status == 'pending') ...[
              const SizedBox(height: 8),
              const Text(
                'Menunggu balasan dari penyuluh...',
                style: TextStyle(fontStyle: FontStyle.italic, color: Colors.orange),
              ),
            ],
            
            const SizedBox(height: 8),
            Text(
              'Dikirim pada: ${request.createdAt?.toString().split(' ')[0] ?? ''}',
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_userId == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Riwayat Permintaan Saran'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _firestoreService.getSaranRequestsByUser(_userId!),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final requests = snapshot.data!.docs;

          if (requests.isEmpty) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.history, size: 64, color: Colors.grey),
                  SizedBox(height: 16),
                  Text('Belum ada riwayat permintaan saran'),
                  SizedBox(height: 8),
                  Text('Ajukan saran perawatan untuk tanaman Anda'),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: requests.length,
            itemBuilder: (context, index) {
              return _buildSaranItem(requests[index]);
            },
          );
        },
      ),
    );
  }
}