import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../utils/constants.dart';
import 'main_scaffold.dart';
import 'login_page.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkLoginStatus();
  }

  Future<void> _checkLoginStatus() async {
    await Future.delayed(const Duration(milliseconds: 900));
    
    final prefs = await SharedPreferences.getInstance();
    final logged = prefs.getBool('is_logged_in') ?? false;
    
    if (mounted) {
      if (logged) {
        final role = prefs.getString('user_role') ?? 'Petani';
        final name = prefs.getString('user_name');
        Navigator.pushReplacement(
          context, 
          MaterialPageRoute(builder: (_) => MainScaffold(role: role, userName: name))
        );
      } else {
        Navigator.pushReplacement(
          context, 
          MaterialPageRoute(builder: (_) => const LoginPage())
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kPalaGreen,
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            decoration: BoxDecoration(color: Colors.white24, shape: BoxShape.circle),
            padding: const EdgeInsets.all(16),
            child: const Icon(Icons.local_florist, size: 84, color: Colors.white),
          ),
          const SizedBox(height: 16),
          const Text(kAppName,
              style: TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.6,
              )),
          const SizedBox(height: 8),
          const Text(kAppDescription,
              style: TextStyle(color: Colors.white70, fontSize: 14)),
        ]),
      ),
    );
  }
}