import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/firestore_services.dart';
import '../../services/shared_prefs_services.dart';
import '../../models/saran_request.dart';
import '../../utils/constants.dart';
import '../widgets/image_widget.dart';

class AdminSaranPage extends StatefulWidget {
  const AdminSaranPage({super.key});

  @override
  State<AdminSaranPage> createState() => _AdminSaranPageState();
}

class _AdminSaranPageState extends State<AdminSaranPage> {
  final FirestoreService _firestoreService = FirestoreService();
  final SharedPrefsService _prefsService = SharedPrefsService();
  final _replyController = TextEditingController();

  @override
  void dispose() {
    _replyController.dispose();
    super.dispose();
  }

  Future<void> _replyToSaran(SaranRequest request) async {
    if (_replyController.text.isEmpty) {
      _showSnackBar('Masukkan saran terlebih dahulu.');
      return;
    }

    final adminData = await _prefsService.getUserData();

    try {
      await _firestoreService.updateSaranReply(
        request.id,
        advice: _replyController.text,
        adminId: adminData['userId'] ?? 'penyuluh',
        adminName: adminData['name'] ?? 'Penyuluh',
        adminReply: _replyController.text,
      );

      _showSnackBar('Saran berhasil dikirim ke petani!');
      _replyController.clear();
      
      if (mounted) {
        Navigator.pop(context);
      }
    } catch (e) {
      _showSnackBar('Gagal mengirim saran: $e');
    }
  }

  void _showReplyDialog(SaranRequest request) {
    _replyController.clear();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Berikan Saran'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Permintaan dari: ${request.userName}'),
              Text('Tanaman: ${request.plantName}'),
              const SizedBox(height: 16),
              const Text('Saran Anda:'),
              const SizedBox(height: 8),
              TextField(
                controller: _replyController,
                maxLines: 6,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Masukkan saran perawatan untuk petani...',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => _replyToSaran(request),
            child: const Text('Kirim Saran'),
          ),
        ],
      ),
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Widget _buildSaranItem(DocumentSnapshot doc) {
    final request = SaranRequest.fromMap(doc.data() as Map<String, dynamic>, doc.id);
    
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  request.plantName,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                Chip(
                  label: Text(
                    request.status == 'pending' ? 'Menunggu' : 
                    request.status == 'replied' ? 'Sudah Dibalas' : 'Selesai',
                    style: const TextStyle(color: Colors.white, fontSize: 12),
                  ),
                  backgroundColor: request.status == 'pending' ? Colors.orange : 
                                 request.status == 'replied' ? Colors.green : Colors.blue,
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text('Dari: ${request.userName} (${request.userEmail})'),
            Text('Jenis Tanah: ${request.soilType}'),
            Text('Tahun Tanam: ${request.plantYear}'),
            const SizedBox(height: 8),
            const Text('Keluhan:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(request.symptoms),
            
            if (request.plantImage.isNotEmpty) ...[
              const SizedBox(height: 8),
              const Text('Foto Tanaman:', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Container(
                height: 100,
                width: 100,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: ImageWidget(imageBase64: request.plantImage),
              ),
            ],
            
            if (request.adminReply != null) ...[
              const SizedBox(height: 8),
              const Text('Saran Anda:', style: TextStyle(fontWeight: FontWeight.bold)),
              Text(request.adminReply!),
              Text(
                'Dibalas pada: ${request.repliedAt?.toString().split(' ')[0] ?? ''}',
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ],
            
            const SizedBox(height: 16),
            if (request.status == 'pending')
              ElevatedButton(
                onPressed: () => _showReplyDialog(request),
                child: const Text('Berikan Saran'),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kelola Permintaan Saran'),
        backgroundColor: kPalaGreen,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _firestoreService.getSaranRequestsStream(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final requests = snapshot.data!.docs;

          if (requests.isEmpty) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.inbox, size: 64, color: Colors.grey),
                  SizedBox(height: 16),
                  Text('Belum ada permintaan saran'),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: requests.length,
            itemBuilder: (context, index) {
              return _buildSaranItem(requests[index]);
            },
          );
        },
      ),
    );
  }
}