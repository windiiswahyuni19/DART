import 'package:flutter/material.dart';
import 'petani_saran_page.dart';
import 'riwayat_saran_page.dart';
import 'admin_saran_page.dart';

class SaranPage extends StatelessWidget {
  final String role;

  const SaranPage({super.key, required this.role});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Saran Perawatan',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            const Text(
              'Ajukan permintaan saran untuk tanaman pala Anda yang bermasalah.',
            ),
            const SizedBox(height: 20),
            
            if (role == 'Petani') ...[
              ElevatedButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const PetaniSaranPage()),
                ),
                icon: const Icon(Icons.add_comment),
                label: const Text('Ajukan Permintaan Saran Baru'),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                ),
              ),
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const RiwayatSaranPage()),
                ),
                icon: const Icon(Icons.history),
                label: const Text('Lihat Riwayat Saran'),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                ),
              ),
            ] else if (role == 'Penyuluh') ...[
              ElevatedButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AdminSaranPage()),
                ),
                icon: const Icon(Icons.message),
                label: const Text('Kelola Permintaan Saran'),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}