import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/pala_item.dart';
import '../models/user.dart';
import '../models/saran_request.dart';

class FirestoreService {
final FirebaseFirestore _firestore = FirebaseFirestore.instance;

// ==================== USER OPERATIONS ====================

Future<void> saveUser(User user) async {
await _firestore.collection('users').doc(user.id).set(user.toMap());
}

Future<Map<String, dynamic>?> getUser(String userId) async {
final doc = await _firestore.collection('users').doc(userId).get();
return doc.data();
}

// ==================== PALA OPERATIONS ====================

/// Get pala stream realtime (filtered by user if needed)
Stream<QuerySnapshot> getPalasStream({String? userId}) {
Query ref = _firestore.collection('pala');

if (userId != null) {
  ref = ref.where('userId', isEqualTo: userId);
}

return ref.orderBy('createdAt', descending: true).snapshots();

}

/// Save or update pala
Future<void> savePala(PalaItem pala, {String? palaId}) async {
if (palaId != null) {
// update existing
await _firestore
.collection('pala')
.doc(palaId)
.set(pala.toMap(), SetOptions(merge: true));
} else {
// create new
await _firestore.collection('pala').add(pala.toMap());
}
}

/// delete pala
Future<void> deletePala(String palaId) async {
await _firestore.collection('pala').doc(palaId).delete();
}

// ==================== SARAN OPERATIONS ====================

Stream<QuerySnapshot> getSaranRequestsStream() {
return _firestore
.collection('saran_requests')
.orderBy('createdAt', descending: true)
.snapshots();
}

Stream<QuerySnapshot> getSaranRequestsByUser(String userId) {
return _firestore
.collection('saran_requests')
.where('userId', isEqualTo: userId)
.orderBy('createdAt', descending: true)
.snapshots();
}

Stream<QuerySnapshot> getPendingSaranRequests() {
return _firestore
.collection('saran_requests')
.where('status', isEqualTo: 'pending')
.orderBy('createdAt', descending: true)
.snapshots();
}

Stream<QuerySnapshot> getRepliedSaranRequests() {
return _firestore
.collection('saran_requests')
.where('status', isEqualTo: 'replied')
.orderBy('repliedAt', descending: true)
.snapshots();
}

Future<void> saveSaranRequest(SaranRequest request) async {
await _firestore.collection('saran_requests').add(request.toMap());
}

Future<void> updateSaranReply(
String requestId, {
required String advice,
required String adminId,
required String adminName,
required String adminReply,
}) async {
await _firestore.collection('saran_requests').doc(requestId).update({
'advice': advice,
'adminId': adminId,
'adminName': adminName,
'adminReply': adminReply,
'status': 'replied',
'repliedAt': DateTime.now(),
});
}

Future<void> markSaranCompleted(String requestId) async {
await _firestore.collection('saran_requests').doc(requestId).update({
'status': 'completed',
});
}

Future<void> deleteSaranRequest(String requestId) async {
await _firestore.collection('saran_requests').doc(requestId).delete();
}

Future<SaranRequest?> getSaranRequestById(String requestId) async {
final doc =
await _firestore.collection('saran_requests').doc(requestId).get();
if (doc.exists) {
return SaranRequest.fromMap(doc.data() as Map<String, dynamic>, doc.id);
}
return null;
}

Future<Map<String, int>> getSaranRequestsCount() async {
final pendingQuery = await _firestore
.collection('saran_requests')
.where('status', isEqualTo: 'pending')
.get();

final repliedQuery = await _firestore
    .collection('saran_requests')
    .where('status', isEqualTo: 'replied')
    .get();

final completedQuery = await _firestore
    .collection('saran_requests')
    .where('status', isEqualTo: 'completed')
    .get();

return {
  'pending': pendingQuery.size,
  'replied': repliedQuery.size,
  'completed': completedQuery.size,
  'total': pendingQuery.size +
      repliedQuery.size +
      completedQuery.size,
};

}

Future<QuerySnapshot> getSaranRequestsPaginated({
int limit = 10,
DocumentSnapshot? lastDocument,
}) {
Query query = _firestore
.collection('saran_requests')
.orderBy('createdAt', descending: true)
.limit(limit);

if (lastDocument != null) {
  query = query.startAfterDocument(lastDocument);
}

return query.get();

}

Stream<QuerySnapshot> searchSaranRequests(String searchTerm) {
return _firestore
.collection('saran_requests')
.where('plantName', isGreaterThanOrEqualTo: searchTerm)
.where('plantName', isLessThan: searchTerm + 'z')
.orderBy('plantName')
.snapshots();
}

Future<Map<String, dynamic>> getSaranStatistics() async {
final now = DateTime.now();
final startOfMonth = DateTime(now.year, now.month, 1);
final startOfWeek = now.subtract(const Duration(days: 7));

final thisMonthQuery = await _firestore
    .collection('saran_requests')
    .where('createdAt', isGreaterThanOrEqualTo: startOfMonth)
    .get();

final thisWeekQuery = await _firestore
    .collection('saran_requests')
    .where('createdAt', isGreaterThanOrEqualTo: startOfWeek)
    .get();

final todayStart = DateTime(now.year, now.month, now.day);
final todayQuery = await _firestore
    .collection('saran_requests')
    .where('createdAt', isGreaterThanOrEqualTo: todayStart)
    .get();

return {
  'today': todayQuery.size,
  'thisWeek': thisWeekQuery.size,
  'thisMonth': thisMonthQuery.size,
};

}

// ==================== NOTIF OPERATIONS ====================

Future<void> saveSaranNotification({
required String userId,
required String title,
required String message,
required String saranRequestId,
}) async {
await _firestore.collection('notifications').add({
'userId': userId,
'title': title,
'message': message,
'saranRequestId': saranRequestId,
'isRead': false,
'createdAt': DateTime.now(),
});
}

Stream<QuerySnapshot> getUserNotifications(String userId) {
return _firestore
.collection('notifications')
.where('userId', isEqualTo: userId)
.orderBy('createdAt', descending: true)
.snapshots();
}

Future<void> markNotificationAsRead(String notificationId) async {
await _firestore.collection('notifications').doc(notificationId).update({
'isRead': true,
});
}

// ==================== UTILITY ====================

Future<bool> hasPendingSaranRequests(String userId) async {
final query = await _firestore
.collection('saran_requests')
.where('userId', isEqualTo: userId)
.where('status', isEqualTo: 'pending')
.limit(1)
.get();

return query.docs.isNotEmpty;

}

Stream<QuerySnapshot> getRecentSaranRequests({int limit = 5}) {
return _firestore
.collection('saran_requests')
.orderBy('createdAt', descending: true)
.limit(limit)
.snapshots();
}

Future<void> updateSaranStatus(String requestId, String status) async {
await _firestore.collection('saran_requests').doc(requestId).update({
'status': status,
if (status == 'replied') 'repliedAt': DateTime.now(),
});
}

Future<void> bulkUpdateSaranRequests(
List<String> requestIds, Map<String, dynamic> updates) async {
final batch = _firestore.batch();

for (final requestId in requestIds) {
  final docRef =
      _firestore.collection('saran_requests').doc(requestId);
  batch.update(docRef, updates);
}

await batch.commit();

}
}