import 'package:shared_preferences/shared_preferences.dart';

class SharedPrefsService {
  static const String _isLoggedInKey = 'is_logged_in';
  static const String _userRoleKey = 'user_role';
  static const String _userNameKey = 'user_name';
  static const String _userEmailKey = 'user_email';
  static const String _userIdKey = 'user_id';
  static const String _penyuluhEmailKey = 'penyuluh_email';
  static const String _penyuluhPassKey = 'penyuluh_pass';
  static const String _penyuluhNameKey = 'penyuluh_name';

  Future<SharedPreferences> get _prefs async => await SharedPreferences.getInstance();

  // Login status
  Future<bool> getIsLoggedIn() async {
    final prefs = await _prefs;
    return prefs.getBool(_isLoggedInKey) ?? false;
  }

  Future<void> setIsLoggedIn(bool value) async {
    final prefs = await _prefs;
    await prefs.setBool(_isLoggedInKey, value);
  }

  // User data
  Future<void> saveUserData({
    required String role,
    required String name,
    required String email,
    required String userId,
  }) async {
    final prefs = await _prefs;
    await prefs.setString(_userRoleKey, role);
    await prefs.setString(_userNameKey, name);
    await prefs.setString(_userEmailKey, email);
    await prefs.setString(_userIdKey, userId);
  }

  Future<Map<String, String?>> getUserData() async {
    final prefs = await _prefs;
    return {
      'role': prefs.getString(_userRoleKey),
      'name': prefs.getString(_userNameKey),
      'email': prefs.getString(_userEmailKey),
      'userId': prefs.getString(_userIdKey),
    };
  }

  // Penyuluh account
  Future<void> setDefaultPenyuluhAccount() async {
    final prefs = await _prefs;
    if (prefs.getString(_penyuluhEmailKey) == null) {
      await prefs.setString(_penyuluhEmailKey, 'admin@gmail.com');
      await prefs.setString(_penyuluhPassKey, '123456');
      await prefs.setString(_penyuluhNameKey, 'Penyuluh');
    }
  }

  Future<Map<String, String?>> getPenyuluhAccount() async {
    final prefs = await _prefs;
    return {
      'email': prefs.getString(_penyuluhEmailKey),
      'password': prefs.getString(_penyuluhPassKey),
      'name': prefs.getString(_penyuluhNameKey),
    };
  }
}