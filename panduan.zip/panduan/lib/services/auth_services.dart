import 'package:firebase_auth/firebase_auth.dart' hide User;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user.dart';
import 'firestore_services.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirestoreService _firestoreService = FirestoreService();

  Future<User?> loginPetani(String email, String password) async {
    try {
      final userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      return await _getUserData(userCredential.user!);
    } on FirebaseAuthException catch (e) {
      throw _handleAuthError(e);
    }
  }

  Future<User?> registerPetani(String name, String email, String password) async {
    try {
      final userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      await userCredential.user!.updateDisplayName(name);
      
      final user = User(
        id: userCredential.user!.uid,
        name: name,
        email: email,
        role: 'Petani',
        createdAt: DateTime.now(),
      );
      
      await _firestoreService.saveUser(user);
      return user;
    } on FirebaseAuthException catch (e) {
      throw _handleAuthError(e);
    }
  }

  Future<void> logout() async {
    await _auth.signOut();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('is_logged_in', false);
  }

  Future<void> resetPassword(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } on FirebaseAuthException catch (e) {
      throw _handleAuthError(e);
    }
  }

  Future<User?> _getUserData( firebaseUser) async {
    final userData = await _firestoreService.getUser(firebaseUser.uid);
    if (userData != null) {
      return User.fromFirestore(userData, firebaseUser.uid);
    }
    
    // Create new user if not exists
    final user = User(
      id: firebaseUser.uid,
      name: firebaseUser.displayName ?? 'Petani',
      email: firebaseUser.email!,
      role: 'Petani',
      lastLogin: DateTime.now(),
    );
    
    await _firestoreService.saveUser(user);
    return user;
  }

  String _handleAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found':
        return 'Email tidak ditemukan.';
      case 'wrong-password':
        return 'Password salah.';
      case 'invalid-email':
        return 'Format email tidak valid.';
      case 'email-already-in-use':
        return 'Email sudah digunakan.';
      case 'weak-password':
        return 'Password terlalu lemah.';
      default:
        return 'Terjadi kesalahan. Silakan coba lagi.';
    }
  }
}