import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../utils/constants.dart';
import '../screens/login_page.dart';
import '../screens/riwayat_saran_page.dart'; // Import RiwayatSaranPage
import '../screens/admin_saran_page.dart'; // Import AdminSaranPage
import '../screens/saran_page_standalone.dart'; 

class AppDrawer extends StatelessWidget {
  final String? userName;
  final String? userRole; // Tambahkan parameter untuk role
  
  const AppDrawer({super.key, this.userName, this.userRole});
  
  @override
  Widget build(BuildContext context) {
    final isPenyuluh = userRole == 'Penyuluh';
    final isPetani = userRole == 'Petani' || userRole == null;

    return Drawer(
      child: SafeArea(
        child: Column(children: [
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(color: kPalaGreen),
            accountName: Text(userName ?? 'Pengguna PalaCare'),
            accountEmail: Text(userRole ?? 'Petani'),
            currentAccountPicture: const CircleAvatar(
              backgroundColor: Colors.white,
              child: Icon(Icons.person, color: kPalaGreen),
            ),
          ),
          
          // Menu Home - untuk semua user
          ListTile(
            leading: const Icon(Icons.home_outlined), 
            title: const Text('Home'), 
            onTap: () {
              Navigator.pop(context);
            }
          ),

          // Menu untuk PETANI saja
          if (isPetani) ...[
            ListTile(
              leading: const Icon(Icons.add_comment), 
              title: const Text('Minta Saran'), 
              onTap: () {
                Navigator.pop(context);
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const SaranPageStandalone())
                );
              }
            ),
            ListTile(
              leading: const Icon(Icons.history), 
              title: const Text('Riwayat Saran'), 
              onTap: () {
                Navigator.pop(context);
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const RiwayatSaranPage())
                );
              }
            ),
          ],

          // Menu untuk PENYULUH saja
          if (isPenyuluh) ...[
            ListTile(
              leading: const Icon(Icons.message), 
              title: const Text('Kelola Saran'), 
              onTap: () {
                Navigator.pop(context);
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const AdminSaranPage())
                );
              }
            ),
            ListTile(
              leading: const Icon(Icons.analytics), 
              title: const Text('Dashboard'), 
              onTap: () {
                Navigator.pop(context);
                // TODO: Tambahkan halaman dashboard untuk penyuluh
                _showSnackBar(context, 'Fitur dashboard sedang dikembangkan');
              }
            ),
          ],

          // Menu untuk semua user
          ListTile(
            leading: const Icon(Icons.lightbulb_outline), 
            title: const Text('Tips Perawatan'), 
            onTap: () {
              Navigator.pop(context);
              _showTipsDialog(context);
            }
          ),

          const Spacer(),

          // Menu informasi
          ListTile(
            leading: const Icon(Icons.help_outline),
            title: const Text('Bantuan'),
            onTap: () {
              Navigator.pop(context);
              _showHelpDialog(context);
            },
          ),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('Tentang PalaCare'),
            onTap: () {
              _showAboutDialog(context);
            },
          ),
          
          // Menu logout
          ListTile(
            leading: const Icon(Icons.logout), 
            title: const Text('Logout'), 
            onTap: () => _logout(context),
          ),
        ]),
      ),
    );
  }

  void _logout(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('is_logged_in', false);
    await prefs.remove('user_role');
    await prefs.remove('user_name');
    await prefs.remove('user_email');
    await prefs.remove('user_id');
    
    if (context.mounted) {
      Navigator.pushReplacement(
        context, 
        MaterialPageRoute(builder: (_) => const LoginPage())
      );
    }
  }

  void _showAboutDialog(BuildContext context) {
    showAboutDialog(
      context: context, 
      applicationName: 'PalaCare', 
      applicationVersion: '1.0.0', 
      applicationIcon: const Icon(Icons.local_florist, color: kPalaGreen),
      children: [
        const SizedBox(height: 16),
        const Text(
          'Aplikasi prototype untuk manajemen dan saran perawatan tanaman pala.',
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 8),
        Text(
          'Role: ${userRole ?? 'Petani'}',
          style: const TextStyle(fontWeight: FontWeight.bold, color: kPalaGreen),
          textAlign: TextAlign.center,
        ),
      ]
    );
  }

  void _showTipsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.lightbulb, color: Colors.amber),
            SizedBox(width: 8),
            Text('Tips Perawatan Pala'),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildTipItem('Pemupukan', 'Berikan pupuk organik setiap 3 bulan sekali'),
              _buildTipItem('Penyiraman', 'Siram secara teratur tapi jangan berlebihan'),
              _buildTipItem('Pemangkasan', 'Pangkas ranting kering secara berkala'),
              _buildTipItem('Pengendalian Hama', 'Gunakan pestisida alami untuk hama'),
              _buildTipItem('Cahaya Matahari', 'Pastikan tanaman mendapat sinar matahari cukup'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  Widget _buildTipItem(String title, String description) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.bold, color: kPalaGreen),
          ),
          Text(
            description,
            style: const TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }

  void _showHelpDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Bantuan & Panduan'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (userRole == 'Petani') ...[
                _buildHelpSection(
                  'Untuk Petani',
                  [
                    '• Gunakan "Minta Saran" untuk konsultasi tanaman',
                    '• Lihat "Riwayat Saran" untuk melihat balasan',
                    '• Tambahkan foto tanaman untuk diagnosis lebih akurat',
                  ],
                ),
              ],
              if (userRole == 'Penyuluh') ...[
                _buildHelpSection(
                  'Untuk Penyuluh',
                  [
                    '• Gunakan "Kelola Saran" untuk membalas permintaan',
                    '• Berikan saran yang detail dan membantu',
                    '• Pantau perkembangan tanaman melalui riwayat',
                  ],
                ),
              ],
              _buildHelpSection(
                'Kontak Darurat',
                [
                  '• Penyuluh Pertanian: 0812-3456-7890',
                  '• Dinas Pertanian: (021) 123-4567',
                  '• Email: palacare@support.com',
                ],
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  Widget _buildHelpSection(String title, List<String> items) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.bold, color: kPalaGreen),
          ),
          const SizedBox(height: 8),
          ...items.map((item) => Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Text(item, style: const TextStyle(fontSize: 14)),
          )),
        ],
      ),
    );
  }

  void _showSnackBar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}