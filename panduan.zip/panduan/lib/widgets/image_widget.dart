import 'package:flutter/material.dart';
import 'dart:typed_data';
import '../../services/image_service.dart';

class ImageWidget extends StatelessWidget {
  final String? imageBase64;
  final double width;
  final double height;
  final BoxFit fit;

  const ImageWidget({
    super.key,
    this.imageBase64,
    this.width = 60,
    this.height = 60,
    this.fit = BoxFit.cover,
  });

  @override
  Widget build(BuildContext context) {
    final imageService = ImageService();
    final Uint8List? imageBytes = imageService.decodeBase64Image(imageBase64);

    if (imageBytes != null) {
      return Image.memory(
        imageBytes,
        width: width,
        height: height,
        fit: fit,
        errorBuilder: (context, error, stackTrace) {
          return _buildDefaultImage();
        },
      );
    }
    return _buildDefaultImage();
  }

  Widget _buildDefaultImage() {
    return Image.asset(
      'assets/images/pala.jpeg',
      width: width,
      height: height,
      fit: fit,
    );
  }
}