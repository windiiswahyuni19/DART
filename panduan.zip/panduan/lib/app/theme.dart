import 'package:flutter/material.dart';
import '../utils/constants.dart';

class AppTheme {
  static final ThemeData lightTheme = ThemeData(
    colorScheme: ColorScheme.fromSeed(seedColor: kPalaGreen),
    scaffoldBackgroundColor: const Color(0xFFF6F7FB),
    useMaterial3: true,
    primaryColor: kPalaGreen,
    appBarTheme: const AppBarTheme(backgroundColor: kPalaGreen),
    fontFamily: 'Poppins',
  );
}