import 'package:flutter/material.dart';
import 'theme.dart';
import '../screens/splash_screen.dart';

class PalaCareApp extends StatelessWidget {
  const PalaCareApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PalaCare',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: const SplashScreen(),
    );
  }
}